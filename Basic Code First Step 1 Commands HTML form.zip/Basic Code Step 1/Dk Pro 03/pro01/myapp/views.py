from django.shortcuts import render
def kat(request):
    if request.method =='GET':
        a=request.GET.get('Username')
        b=request.GET.get('Password')
        print(a)
        print(b)
    return render(request,"track.html")

